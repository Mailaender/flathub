/*
**  ClanLib SDK
**  Copyright (c) 1997-2005 The ClanLib Team
**
**  This software is provided 'as-is', without any express or implied
**  warranty.  In no event will the authors be held liable for any damages
**  arising from the use of this software.
**
**  Permission is granted to anyone to use this software for any purpose,
**  including commercial applications, and to alter it and redistribute it
**  freely, subject to the following restrictions:
**
**  1. The origin of this software must not be misrepresented; you must not
**     claim that you wrote the original software. If you use this software
**     in a product, an acknowledgment in the product documentation would be
**     appreciated but is not required.
**  2. Altered source versions must be plainly marked as such, and must not be
**     misrepresented as being the original software.
**  3. This notice may not be removed or altered from any source distribution.
**
**  Note: Some of the libraries ClanLib may link to may have additional
**  requirements or restrictions.
**
**  File Author(s):
**
**    Magnus Norddahl
**    (if your name is missing here, please add it)
*/

#ifndef header_console_window_generic
#define header_console_window_generic

#if _MSC_VER > 1000
#pragma once
#endif

#include <string>
#include <cstdio>

class CL_ConsoleWindow_Generic
{
//! Construction:
public:
	CL_ConsoleWindow_Generic(
		const std::string &title,
		int width,
		int height);

	~CL_ConsoleWindow_Generic();

//! Operations:
public:
	void redirect_stdio();

	void redirect_stdio(const std::string &file);

	void wait_for_key();
	void display_close_message();

//! Implementation:
private:
	void close_file_handles();

#ifdef _MSC_VER
	FILE *fstdout;
	FILE *fstdin;
	FILE *fstderr;
#else
	std::FILE *fstdout;
	std::FILE *fstdin;
	std::FILE *fstderr;
#endif
};

#endif
